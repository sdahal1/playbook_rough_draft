/* 
Using an api endpoint like this: https://pokeapi.co/api/v2/pokemon/ditto

Write a function that takes a pokemon name and gives back an object similar to this:
{
  name: "ditto",
  abilities: [{},{}],
  height: 3,
  base_experience: 48
}



Bonus challenge: Output an object similar to the following: 
{
  name: "ditto",
  firstAbilityName: "limber",
  firstMove: "transform"
}



If you don't know any pokemon names to test this with, here are some to get you started:
pikachu
charmander
bulbasaur
*/


function catchEmAll(pokemonName) {
  
}

catchEmAll("pikachu")