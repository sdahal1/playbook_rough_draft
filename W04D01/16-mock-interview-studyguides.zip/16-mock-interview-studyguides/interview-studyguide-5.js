/* 
Using an api endpoint like this: https://pokeapi.co/api/v2/pokemon/ditto

Write a function that takes a pokemon name and gives back an object similar to this:

{
  name: "ditto",
  firstAbilityName: "limber",
  firstMove: "transform"
}

Note: the value for the first ability name can be found somewhere in the 'abilities' property, and the first move name can be found in the 'moves' property

If you don't know any pokemon names to test this with, here are some to get you started:
pikachu
charmander
bulbasaur
*/


function catchEmAll(pokemonName) {
  
}

catchEmAll("pikachu")