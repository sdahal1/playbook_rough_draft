//GET ALL PLAYERS
function findAllPlayers(){

}
//GET ONE PLAYER BY ID
function findPlayerById(id){

}
//CREATE A NEW PLAYER
function createPlayer(info){

} 
//UPDATE PLAYER BY ID
function updatePlayer(id){

}

//DELETE PLAYER BY ID
function deletePlayer(id){
  
}