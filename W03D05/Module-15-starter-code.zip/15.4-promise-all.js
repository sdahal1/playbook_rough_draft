const axios = require("axios");
const BASE_URL = "http://localhost:5001";

function bulkFind(ids=[]){
}

function bulkDelete(ids=[]) {
}