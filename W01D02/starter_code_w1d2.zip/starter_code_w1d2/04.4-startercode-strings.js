//Concept: all strings are immutable
let cool_quote = "how YOU DO anyTHInG is How You dO eVERyThING"



// Strings have indices



// You can get length of a string




// You can loop through a string




// lets create the sentence case function
function sentenceCase(inputString){

}

sentenceCase("waZZAAAP though?") //Wazzaaap though?


// the substring() method: Gives you a portion of a string



// lets do sentence case function using the substring method!




// Splitting a string: Split string at each indicated character and put it into an array


// Joining elements from an array into a string



// Explain how titelize works in platform using split and join



// Template literals



// Escaping strings



// Study guide time!

