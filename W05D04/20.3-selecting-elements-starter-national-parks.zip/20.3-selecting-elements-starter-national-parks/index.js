//SANITY CHECK

/*
NOTES:
- document.querySelector() --> to select the first element on the page that matches the query
- document.querySelectorAll() --> to select all elements on the page that matches the query

*/


// 1. Select the first h1 selector

// 2. Select all h1 selectors

// 3. Select the first section with the class of park-display

// 4. Select the first established date value

// 5. Select all the established date values

// 6. Select all the area values

// 7. Write a statement that will find the Grand Canyon national park element by its ID.

// 8. Write a statement that will find the element containing the established date for the Grand Canyon national park.


